Created by chillyastronox
Nov 4 2025

How to run:
Run main.py with python3 to open program
